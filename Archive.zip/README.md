# bioGARAGE
bioGARAGE static website for general public information and
quick contact to bioGARAGE personnel.

Author: Alexander Moussa
