$(document).ready(function(){
  /* ---- sets home menu active for specific page---- */
  $('.menu-link-4').addClass('selectedPage');

})
